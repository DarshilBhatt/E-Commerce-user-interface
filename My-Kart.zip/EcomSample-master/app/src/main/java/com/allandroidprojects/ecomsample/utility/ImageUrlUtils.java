package com.allandroidprojects.ecomsample.utility;

import com.allandroidprojects.ecomsample.R;

import java.util.ArrayList;

/**
 * Created by 06peng on 2015/6/24.
 */
public class ImageUrlUtils {
    static ArrayList<String> wishlistImageUri = new ArrayList<>();
    static ArrayList<String> cartListImageUri = new ArrayList<>();

    public static String[] getImageUrls() {
        String[] urls = new String[] {

        };
        return urls;
    }

    public static String[] getOffersUrls() {
        String [] urls = new String[]{


                "http://adriit.com/darshil/1.jpg"

        };
        return urls;
    }

    public static String[] getHomeApplianceUrls() {
        String[] urls = new String[]{
               /*"https://images.homedepot-static.com/productImages/732db3ae-4b52-4c4a-9b5d-1b645d8f1fed/svn/stainless-steel-frigidaire-top-freezer-refrigerators-ffht1821ts-64_1000.jpg",
                "https://brain-images-ssl.cdn.dixons.com/9/8/10140689/u_10140689.jpg",
                "https://cdn2.harveynorman.com.au/media/catalog/product/cache/21/image/992x558/9df78eab33525d08d6e5fb8d27136e95/i/m/image_1_1_35.jpg",
                "https://cdn-live-wwf0uvrcwyr9hig.stackpathdns.com/media/catalog/product/e/u/eureka_forbes-wp-8664-v1-min.jpg",
                "https://images.homedepot-static.com/productImages/732db3ae-4b52-4c4a-9b5d-1b645d8f1fed/svn/stainless-steel-frigidaire-top-freezer-refrigerators-ffht1821ts-64_1000.jpg",
                "https://brain-images-ssl.cdn.dixons.com/9/8/10140689/u_10140689.jpg",
                "https://cdn2.harveynorman.com.au/media/catalog/product/cache/21/image/992x558/9df78eab33525d08d6e5fb8d27136e95/i/m/image_1_1_35.jpg",
                "https://cdn-live-wwf0uvrcwyr9hig.stackpathdns.com/media/catalog/product/e/u/eureka_forbes-wp-8664-v1-min.jpg",
                "https://images.homedepot-static.com/productImages/732db3ae-4b52-4c4a-9b5d-1b645d8f1fed/svn/stainless-steel-frigidaire-top-freezer-refrigerators-ffht1821ts-64_1000.jpg",
                "https://brain-images-ssl.cdn.dixons.com/9/8/10140689/u_10140689.jpg",
                "https://cdn2.harveynorman.com.au/media/catalog/product/cache/21/image/992x558/9df78eab33525d08d6e5fb8d27136e95/i/m/image_1_1_35.jpg",
                "https://cdn-live-wwf0uvrcwyr9hig.stackpathdns.com/media/catalog/product/e/u/eureka_forbes-wp-8664-v1-min.jpg",
                "https://images.homedepot-static.com/productImages/732db3ae-4b52-4c4a-9b5d-1b645d8f1fed/svn/stainless-steel-frigidaire-top-freezer-refrigerators-ffht1821ts-64_1000.jpg",
                "https://brain-images-ssl.cdn.dixons.com/9/8/10140689/u_10140689.jpg",
                "https://cdn2.harveynorman.com.au/media/catalog/product/cache/21/image/992x558/9df78eab33525d08d6e5fb8d27136e95/i/m/image_1_1_35.jpg",
                "https://cdn-live-wwf0uvrcwyr9hig.stackpathdns.com/media/catalog/product/e/u/eureka_forbes-wp-8664-v1-min.jpg",*/
               "http://adriit.com/darshil/2.jpg"

        };
        return urls;
    }

    public static String[] getElectronicsUrls() {
        String[] urls = new String[]{
                /*"https://store.storeimages.cdn-apple.com/4980/as-images.apple.com/is/image/AppleInc/aos/published/images/i/ph/iphone/x/iphone-x-silver-select-2017?wid=305&hei=358&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=1515602510472",
                "https://cnet2.cbsistatic.com/img/iXxss99B0PZw39Vybe39YEBmcNs=/830x467/2017/08/14/ec0fa893-faf2-46c3-8933-6898773804ba/apple-macbook-air-2017-05.jpg",
                "https://cf1.s3.souqcdn.com/item/2016/12/14/12/01/99/33/item_XL_12019933_18013971.jpg",
                "https://static.digit.in/product/847db6b29eddb0b329441c25d2732e782ed81c9f.jpeg",
                "https://store.storeimages.cdn-apple.com/4980/as-images.apple.com/is/image/AppleInc/aos/published/images/i/ph/iphone/x/iphone-x-silver-select-2017?wid=305&hei=358&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=1515602510472",
                "https://cnet2.cbsistatic.com/img/iXxss99B0PZw39Vybe39YEBmcNs=/830x467/2017/08/14/ec0fa893-faf2-46c3-8933-6898773804ba/apple-macbook-air-2017-05.jpg",
                "https://cf1.s3.souqcdn.com/item/2016/12/14/12/01/99/33/item_XL_12019933_18013971.jpg",
                "https://static.digit.in/product/847db6b29eddb0b329441c25d2732e782ed81c9f.jpeg",
                "https://store.storeimages.cdn-apple.com/4980/as-images.apple.com/is/image/AppleInc/aos/published/images/i/ph/iphone/x/iphone-x-silver-select-2017?wid=305&hei=358&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=1515602510472",
                "https://cnet2.cbsistatic.com/img/iXxss99B0PZw39Vybe39YEBmcNs=/830x467/2017/08/14/ec0fa893-faf2-46c3-8933-6898773804ba/apple-macbook-air-2017-05.jpg",
                "https://cf1.s3.souqcdn.com/item/2016/12/14/12/01/99/33/item_XL_12019933_18013971.jpg",
                "https://static.digit.in/product/847db6b29eddb0b329441c25d2732e782ed81c9f.jpeg",
                "https://store.storeimages.cdn-apple.com/4980/as-images.apple.com/is/image/AppleInc/aos/published/images/i/ph/iphone/x/iphone-x-silver-select-2017?wid=305&hei=358&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=1515602510472",
                "https://cnet2.cbsistatic.com/img/iXxss99B0PZw39Vybe39YEBmcNs=/830x467/2017/08/14/ec0fa893-faf2-46c3-8933-6898773804ba/apple-macbook-air-2017-05.jpg",
                "https://cf1.s3.souqcdn.com/item/2016/12/14/12/01/99/33/item_XL_12019933_18013971.jpg",
                "https://static.digit.in/product/847db6b29eddb0b329441c25d2732e782ed81c9f.jpeg"*/
                "http://adriit.com/darshil/3.jpg"
        };
        return urls;
    }

    public static String[] getLifeStyleUrls() {
        String[] urls = new String[]{
               /* "https://i.ytimg.com/vi/fp0-dsx_lVI/maxresdefault.jpg",
                "https://3.imimg.com/data3/MY/UH/MY-13357616/home-furniture-500x500.jpg",
                "http://www.decoveco.com/skin/frontend/intenso/default/images/homepage_banner_02.jpg",
                "https://www.durian.in/blog/wp-content/uploads/2018/06/Featured-Image.jpg",
                "https://i.ytimg.com/vi/fp0-dsx_lVI/maxresdefault.jpg",
                "https://3.imimg.com/data3/MY/UH/MY-13357616/home-furniture-500x500.jpg",
                "http://www.decoveco.com/skin/frontend/intenso/default/images/homepage_banner_02.jpg",
                "https://www.durian.in/blog/wp-content/uploads/2018/06/Featured-Image.jpg",
                "https://i.ytimg.com/vi/fp0-dsx_lVI/maxresdefault.jpg",
                "https://3.imimg.com/data3/MY/UH/MY-13357616/home-furniture-500x500.jpg",
                "http://www.decoveco.com/skin/frontend/intenso/default/images/homepage_banner_02.jpg",
                "https://www.durian.in/blog/wp-content/uploads/2018/06/Featured-Image.jpg",
                "https://i.ytimg.com/vi/fp0-dsx_lVI/maxresdefault.jpg",
                "https://3.imimg.com/data3/MY/UH/MY-13357616/home-furniture-500x500.jpg",
                "http://www.decoveco.com/skin/frontend/intenso/default/images/homepage_banner_02.jpg",*/
        "http://adriit.com/darshil/4.jpg"};
        return urls;
    }

    public static String[] getBooksUrls() {
        String[] urls = new String[]{

                /*"https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1295670969i/634583._UY475_SS475_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51VLrw0NOaL._SX323_BO1,204,203,200_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51D8GfpoPKL._SX325_BO1,204,203,200_.jpg",
                "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1295670969i/634583._UY475_SS475_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51VLrw0NOaL._SX323_BO1,204,203,200_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51D8GfpoPKL._SX325_BO1,204,203,200_.jpg",
                "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1295670969i/634583._UY475_SS475_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51VLrw0NOaL._SX323_BO1,204,203,200_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51D8GfpoPKL._SX325_BO1,204,203,200_.jpg",
                "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1295670969i/634583._UY475_SS475_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51VLrw0NOaL._SX323_BO1,204,203,200_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51D8GfpoPKL._SX325_BO1,204,203,200_.jpg"*/
                "http://adriit.com/darshil/5.jpg"
        };
        return urls;
    }

    public static String[] getMoreUrls() {
        String[] urls = new String[]{
                /*"https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1295670969i/634583._UY475_SS475_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51VLrw0NOaL._SX323_BO1,204,203,200_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51D8GfpoPKL._SX325_BO1,204,203,200_.jpg",
                "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1295670969i/634583._UY475_SS475_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51VLrw0NOaL._SX323_BO1,204,203,200_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51D8GfpoPKL._SX325_BO1,204,203,200_.jpg",
                "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1295670969i/634583._UY475_SS475_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51VLrw0NOaL._SX323_BO1,204,203,200_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51D8GfpoPKL._SX325_BO1,204,203,200_.jpg",
                "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1295670969i/634583._UY475_SS475_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51VLrw0NOaL._SX323_BO1,204,203,200_.jpg",
                "https://images-na.ssl-images-amazon.com/images/I/51D8GfpoPKL._SX325_BO1,204,203,200_.jpg"*/
                "http://adriit.com/darshil/5.jpg"


        };
        return urls;
    }

    // Methods for Wishlist
    public void addWishlistImageUri(String wishlistImageUri) {
        this.wishlistImageUri.add(0,wishlistImageUri);
    }

    public void removeWishlistImageUri(int position) {
        this.wishlistImageUri.remove(position);
    }

    public ArrayList<String> getWishlistImageUri(){ return this.wishlistImageUri; }

    // Methods for Cart
    public void addCartListImageUri(String wishlistImageUri) {
        this.cartListImageUri.add(0,wishlistImageUri);
    }

    public void removeCartListImageUri(int position) {
        this.cartListImageUri.remove(position);
    }

    public ArrayList<String> getCartListImageUri(){ return this.cartListImageUri; }
}
